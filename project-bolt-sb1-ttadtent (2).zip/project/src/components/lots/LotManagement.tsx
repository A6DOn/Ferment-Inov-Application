import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, Edit, Trash2, Download } from 'lucide-react';
import { LotCard } from './LotCard';
import { CreateLotModal } from './CreateLotModal';

const mockLots = [
  {
    id: 'LOT-2025-001',
    type: 'Trinitario',
    quantity: 500,
    phase: 'Fermentation' as const,
    status: 'active' as const,
    startDate: '2025-01-15',
    currentDay: 3,
    totalDays: 6,
    temperature: 45.2,
    humidity: 72,
    quality: 'excellent' as const
  },
  {
    id: 'LOT-2025-002',
    type: 'Forastero',
    quantity: 750,
    phase: 'Séchage' as const,
    status: 'active' as const,
    startDate: '2025-01-12',
    currentDay: 2,
    totalDays: 8,
    temperature: 38.5,
    humidity: 45,
    quality: 'good' as const
  },
  {
    id: 'LOT-2025-003',
    type: 'Criollo',
    quantity: 300,
    phase: 'Terminé' as const,
    status: 'completed' as const,
    startDate: '2025-01-01',
    currentDay: 14,
    totalDays: 14,
    temperature: 25.0,
    humidity: 40,
    quality: 'excellent' as const
  }
];

export function LotManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'completed'>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);

  const filteredLots = mockLots.filter(lot => {
    const matchesSearch = lot.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lot.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || lot.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Gestion des Lots</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200 shadow-sm"
        >
          <Plus className="h-4 w-4" />
          <span>Nouveau Lot</span>
        </button>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Rechercher par ID ou type de fève..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 bg-white"
            >
              <option value="all">Tous les statuts</option>
              <option value="active">Actifs</option>
              <option value="completed">Terminés</option>
            </select>
          </div>
        </div>
      </div>

      {/* Lots Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredLots.map((lot) => (
          <LotCard key={lot.id} lot={lot} />
        ))}
      </div>

      {filteredLots.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <Search className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun lot trouvé</h3>
          <p className="text-gray-500">Essayez de modifier vos critères de recherche.</p>
        </div>
      )}

      <CreateLotModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />
    </div>
  );
}