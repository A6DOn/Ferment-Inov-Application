import React, { useState } from 'react';
import { X } from 'lucide-react';

interface CreateLotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const cocoaTypes = [
  { value: 'trinitario', label: 'Trinitario' },
  { value: 'forastero', label: 'Forastero' },
  { value: 'criollo', label: 'Criollo' },
  { value: 'nacional', label: 'Nacional' }
];

export function CreateLotModal({ isOpen, onClose }: CreateLotModalProps) {
  const [formData, setFormData] = useState({
    type: '',
    quantity: '',
    startPhase: 'fermentation'
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the data to your backend
    console.log('Creating lot:', formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Créer un nouveau lot</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de fève de cacao
            </label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            >
              <option value="">Sélectionner un type</option>
              {cocoaTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Quantité (kg)
            </label>
            <input
              type="number"
              min="1"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              placeholder="500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phase de départ
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="startPhase"
                  value="fermentation"
                  checked={formData.startPhase === 'fermentation'}
                  onChange={(e) => setFormData({ ...formData, startPhase: e.target.value })}
                  className="h-4 w-4 text-green-600 focus:ring-green-500"
                />
                <span className="ml-2 text-sm text-gray-700">Fermentation</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="startPhase"
                  value="drying"
                  checked={formData.startPhase === 'drying'}
                  onChange={(e) => setFormData({ ...formData, startPhase: e.target.value })}
                  className="h-4 w-4 text-green-600 focus:ring-green-500"
                />
                <span className="ml-2 text-sm text-gray-700">Séchage</span>
              </label>
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200"
            >
              Créer le lot
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}