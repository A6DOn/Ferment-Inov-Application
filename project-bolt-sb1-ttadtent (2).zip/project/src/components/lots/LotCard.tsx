import React from 'react';
import { Calendar, Thermometer, Droplets, Eye, Edit, Download, AlertTriangle } from 'lucide-react';
import { ProgressCard } from '../ui/ProgressCard';

interface Lot {
  id: string;
  type: string;
  quantity: number;
  phase: 'Fermentation' | 'Séchage' | 'Terminé';
  status: 'active' | 'completed';
  startDate: string;
  currentDay: number;
  totalDays: number;
  temperature: number;
  humidity: number;
  quality: 'excellent' | 'good' | 'average';
}

interface LotCardProps {
  lot: Lot;
}

const phaseColors = {
  Fermentation: 'blue',
  Séchage: 'amber',
  Terminé: 'green'
} as const;

const qualityColors = {
  excellent: 'bg-green-100 text-green-800',
  good: 'bg-blue-100 text-blue-800',
  average: 'bg-amber-100 text-amber-800'
};

const qualityLabels = {
  excellent: 'Excellent',
  good: 'Bon',
  average: 'Moyen'
};

export function LotCard({ lot }: LotCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{lot.id}</h3>
          <p className="text-sm text-gray-500">{lot.type} • {lot.quantity}kg</p>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${qualityColors[lot.quality]}`}>
            {qualityLabels[lot.quality]}
          </span>
          {lot.phase !== 'Terminé' && lot.humidity > 70 && (
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Calendar className="h-4 w-4" />
          <span>Début: {new Date(lot.startDate).toLocaleDateString('fr-FR')}</span>
        </div>

        <div className={`px-3 py-2 rounded-lg text-center font-medium ${
          lot.status === 'active' 
            ? 'bg-green-50 text-green-700 border border-green-200' 
            : 'bg-gray-50 text-gray-600 border border-gray-200'
        }`}>
          {lot.phase}
        </div>

        <ProgressCard
          label="Progression"
          current={lot.currentDay}
          total={lot.totalDays}
          color={phaseColors[lot.phase]}
        />

        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-red-50 rounded-lg">
              <Thermometer className="h-4 w-4 text-red-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Température</p>
              <p className="font-medium text-gray-900">{lot.temperature}°C</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Droplets className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-gray-500">Humidité</p>
              <p className="font-medium text-gray-900">{lot.humidity}%</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex space-x-2">
            <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
              <Eye className="h-4 w-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors">
              <Edit className="h-4 w-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
              <Download className="h-4 w-4" />
            </button>
          </div>
          <div className="text-xs text-gray-500">
            {lot.status === 'active' ? `${lot.totalDays - lot.currentDay} jours restants` : 'Terminé'}
          </div>
        </div>
      </div>
    </div>
  );
}