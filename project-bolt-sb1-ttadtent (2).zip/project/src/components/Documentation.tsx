import React, { useState } from 'react';
import { BookOpen, Search, Download, FileText, Video, HelpCircle } from 'lucide-react';

const documentationSections = [
  {
    id: 'getting-started',
    title: 'Guide de Démarrage',
    icon: <BookOpen className="h-5 w-5" />,
    articles: [
      { title: 'Introduction à Ferment\'Innov', type: 'article' },
      { title: 'Configuration initiale du système', type: 'video' },
      { title: 'Première utilisation', type: 'article' }
    ]
  },
  {
    id: 'fermentation',
    title: 'Processus de Fermentation',
    icon: <FileText className="h-5 w-5" />,
    articles: [
      { title: 'Paramètres optimaux par type de fève', type: 'article' },
      { title: 'Contrôle de la température', type: 'video' },
      { title: 'Gestion de l\'humidité', type: 'article' },
      { title: 'Durées de fermentation recommandées', type: 'article' }
    ]
  },
  {
    id: 'drying',
    title: 'Processus de Séchage',
    icon: <FileText className="h-5 w-5" />,
    articles: [
      { title: 'Conditions météorologiques et séchage', type: 'article' },
      { title: 'Contrôle automatique vs manuel', type: 'video' },
      { title: 'Indicateurs de qualité', type: 'article' }
    ]
  },
  {
    id: 'troubleshooting',
    title: 'Dépannage',
    icon: <HelpCircle className="h-5 w-5" />,
    articles: [
      { title: 'Problèmes courants et solutions', type: 'article' },
      { title: 'Codes d\'erreur du système IoT', type: 'article' },
      { title: 'Contact support technique', type: 'article' }
    ]
  }
];

export function Documentation() {
  const [activeSection, setActiveSection] = useState('getting-started');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSections = documentationSections.map(section => ({
    ...section,
    articles: section.articles.filter(article =>
      article.title.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Documentation</h1>
        <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Download className="h-4 w-4" />
          <span>Guide PDF</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        <input
          type="text"
          placeholder="Rechercher dans la documentation..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Sections</h3>
            <nav className="space-y-1">
              {filteredSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center space-x-3 px-3 py-2 text-left rounded-lg transition-colors ${
                    activeSection === section.id
                      ? 'bg-green-50 text-green-700 border border-green-200'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {section.icon}
                  <span className="text-sm font-medium">{section.title}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            {filteredSections
              .filter(section => section.id === activeSection)
              .map((section) => (
                <div key={section.id} className="p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="p-2 bg-green-50 rounded-lg">
                      {section.icon}
                    </div>
                    <h2 className="text-xl font-semibold text-gray-900">{section.title}</h2>
                  </div>

                  <div className="space-y-4">
                    {section.articles.map((article, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-50 rounded-lg">
                            {article.type === 'video' ? (
                              <Video className="h-4 w-4 text-blue-600" />
                            ) : (
                              <FileText className="h-4 w-4 text-blue-600" />
                            )}
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900">{article.title}</h3>
                            <p className="text-sm text-gray-500 capitalize">{article.type}</p>
                          </div>
                        </div>
                        <div className="text-gray-400">
                          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      </div>
                    ))}
                  </div>

                  {section.articles.length === 0 && searchTerm && (
                    <div className="text-center py-8">
                      <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <Search className="h-6 w-6 text-gray-400" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun résultat</h3>
                      <p className="text-gray-500">Aucun article trouvé pour "{searchTerm}"</p>
                    </div>
                  )}
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}