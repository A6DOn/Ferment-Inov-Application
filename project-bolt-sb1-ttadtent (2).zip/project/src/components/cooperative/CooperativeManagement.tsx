import React, { useState } from 'react';
import { Users, Building2, MapPin, BarChart3, Settings, Plus, Edit, Trash2, Eye, UserPlus, Shield } from 'lucide-react';

interface Cooperative {
  id: string;
  name: string;
  location: string;
  memberCount: number;
  machineCount: number;
  totalProduction: number;
  status: 'active' | 'inactive';
}

interface Member {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'operator' | 'viewer';
  joinDate: string;
  lastActive: string;
  cooperativeId: string;
}

const mockCooperatives: Cooperative[] = [
  {
    id: 'COOP-001',
    name: 'Coopérative Cacao Ivoire',
    location: 'Abidjan, Côte d\'Ivoire',
    memberCount: 45,
    machineCount: 8,
    totalProduction: 12500,
    status: 'active'
  },
  {
    id: 'COOP-002',
    name: 'Union des Producteurs Ghana',
    location: 'Kumasi, Ghana',
    memberCount: 32,
    machineCount: 5,
    totalProduction: 8900,
    status: 'active'
  }
];

const mockMembers: Member[] = [
  {
    id: 'MEM-001',
    name: 'Kouassi Yao',
    email: 'k.yao@cacao-ivoire.com',
    role: 'admin',
    joinDate: '2024-01-15',
    lastActive: '2025-01-15T10:30:00Z',
    cooperativeId: 'COOP-001'
  },
  {
    id: 'MEM-002',
    name: 'Ama Asante',
    email: 'a.asante@ghana-union.com',
    role: 'operator',
    joinDate: '2024-03-20',
    lastActive: '2025-01-14T16:45:00Z',
    cooperativeId: 'COOP-001'
  }
];

export function CooperativeManagement() {
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'machines' | 'analytics' | 'settings'>('overview');
  const [selectedCooperative, setSelectedCooperative] = useState<string>('COOP-001');

  const currentCooperative = mockCooperatives.find(coop => coop.id === selectedCooperative);
  const cooperativeMembers = mockMembers.filter(member => member.cooperativeId === selectedCooperative);

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-800';
      case 'operator': return 'bg-blue-100 text-blue-800';
      case 'viewer': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'Administrateur';
      case 'operator': return 'Opérateur';
      case 'viewer': return 'Observateur';
      default: return role;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg">
            <Building2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion Coopérative</h1>
            <p className="text-sm text-gray-500">Supervision multi-sites et multi-utilisateurs</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <select
            value={selectedCooperative}
            onChange={(e) => setSelectedCooperative(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            {mockCooperatives.map((coop) => (
              <option key={coop.id} value={coop.id}>
                {coop.name}
              </option>
            ))}
          </select>
          <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200">
            <Plus className="h-4 w-4" />
            <span>Nouvelle Coopérative</span>
          </button>
        </div>
      </div>

      {/* Cooperative Info Card */}
      {currentCooperative && (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">{currentCooperative.name}</h2>
              <div className="flex items-center space-x-2 text-gray-600 mt-1">
                <MapPin className="h-4 w-4" />
                <span>{currentCooperative.location}</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600">{currentCooperative.memberCount}</div>
                <div className="text-sm text-gray-600">Membres</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">{currentCooperative.machineCount}</div>
                <div className="text-sm text-gray-600">Machines</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">{currentCooperative.totalProduction}kg</div>
                <div className="text-sm text-gray-600">Production</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {[
            { id: 'overview', label: 'Vue d\'ensemble', icon: BarChart3 },
            { id: 'members', label: 'Membres', icon: Users },
            { id: 'machines', label: 'Machines', icon: Settings },
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            { id: 'settings', label: 'Paramètres', icon: Shield }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Activité Récente</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Nouveau lot créé - LOT-2025-003</p>
                    <p className="text-xs text-gray-500">Il y a 2 heures</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Machine FI-2025-005 connectée</p>
                    <p className="text-xs text-gray-500">Il y a 4 heures</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-amber-50 rounded-lg">
                  <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Alerte humidité - Site Kumasi</p>
                    <p className="text-xs text-gray-500">Il y a 6 heures</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Mensuelle</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Production totale</span>
                  <span className="font-semibold text-gray-900">2,450 kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Lots traités</span>
                  <span className="font-semibold text-gray-900">18</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Taux de qualité</span>
                  <span className="font-semibold text-green-600">94.2%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Machines actives</span>
                  <span className="font-semibold text-gray-900">7/8</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'members' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">Membres de la Coopérative</h3>
              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <UserPlus className="h-4 w-4" />
                <span>Inviter un Membre</span>
              </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Membre
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rôle
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Dernière Activité
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cooperativeMembers.map((member) => (
                    <tr key={member.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium text-gray-600">
                              {member.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{member.name}</div>
                            <div className="text-sm text-gray-500">{member.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleColor(member.role)}`}>
                          {getRoleLabel(member.role)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(member.lastActive).toLocaleDateString('fr-FR')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <button className="text-blue-600 hover:text-blue-900">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="text-green-600 hover:text-green-900">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'machines' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Machines de la Coopérative</h3>
            <p className="text-gray-500">Fonctionnalité en développement - Gestion centralisée des machines IoT</p>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Analytics Avancés</h3>
            <p className="text-gray-500">Fonctionnalité en développement - Rapports consolidés et métriques de performance</p>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Paramètres de la Coopérative</h3>
            <p className="text-gray-500">Fonctionnalité en développement - Configuration des paramètres globaux</p>
          </div>
        )}
      </div>
    </div>
  );
}