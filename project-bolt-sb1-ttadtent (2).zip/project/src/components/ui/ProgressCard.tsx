import React from 'react';

interface ProgressCardProps {
  label: string;
  current: number;
  total: number;
  color: 'blue' | 'amber' | 'green';
}

const colorClasses = {
  blue: 'bg-blue-500',
  amber: 'bg-amber-500',
  green: 'bg-green-500'
};

export function ProgressCard({ label, current, total, color }: ProgressCardProps) {
  const percentage = (current / total) * 100;

  return (
    <div>
      <div className="flex items-center justify-between text-sm mb-2">
        <span className="text-gray-600">{label}</span>
        <span className="font-medium text-gray-900">Jour {current}/{total}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className={`h-2 rounded-full transition-all duration-500 ${colorClasses[color]}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}