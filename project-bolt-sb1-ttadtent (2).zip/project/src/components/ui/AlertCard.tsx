import React from 'react';
import { AlertTriangle, Info, CheckCircle2, X } from 'lucide-react';

interface AlertCardProps {
  type: 'warning' | 'info' | 'success' | 'error';
  title: string;
  message: string;
  className?: string;
  onClose?: () => void;
}

const alertStyles = {
  warning: {
    container: 'bg-amber-50 border-amber-200 text-amber-800',
    icon: AlertTriangle,
    iconColor: 'text-amber-600'
  },
  info: {
    container: 'bg-blue-50 border-blue-200 text-blue-800',
    icon: Info,
    iconColor: 'text-blue-600'
  },
  success: {
    container: 'bg-green-50 border-green-200 text-green-800',
    icon: CheckCircle2,
    iconColor: 'text-green-600'
  },
  error: {
    container: 'bg-red-50 border-red-200 text-red-800',
    icon: AlertTriangle,
    iconColor: 'text-red-600'
  }
};

export function AlertCard({ type, title, message, className = '', onClose }: AlertCardProps) {
  const style = alertStyles[type];
  const Icon = style.icon;

  return (
    <div className={`border rounded-lg p-4 ${style.container} ${className}`}>
      <div className="flex items-start space-x-3">
        <Icon className={`h-5 w-5 ${style.iconColor} mt-0.5 flex-shrink-0`} />
        <div className="flex-1">
          <h4 className="font-medium">{title}</h4>
          <p className="text-sm mt-1">{message}</p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="ml-2 flex-shrink-0 p-0.5 hover:bg-black/10 rounded transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}