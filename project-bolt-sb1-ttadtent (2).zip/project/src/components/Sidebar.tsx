import React from 'react';
import { X, BarChart3, Package, Settings, BookOpen, Shield, Thermometer, Brain } from 'lucide-react';
import { AppView } from '../App';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentView: AppView;
  onViewChange: (view: AppView) => void;
  userRole: 'admin' | 'operator' | 'viewer';
}

const menuItems = [
  { id: 'dashboard' as AppView, label: 'Dashboard', icon: BarChart3, roles: ['admin', 'operator', 'viewer'] },
  { id: 'lots' as AppView, label: 'Gestion des Lots', icon: Package, roles: ['admin', 'operator'] },
  { id: 'iot-control' as AppView, label: 'Contrôle IoT', icon: Thermometer, roles: ['admin', 'operator'] },
  { id: 'ai-insights' as AppView, label: 'IA & Insights', icon: Brain, roles: ['admin', 'operator'] },
  { id: 'documentation' as AppView, label: 'Documentation', icon: BookOpen, roles: ['admin', 'operator', 'viewer'] },
  { id: 'admin' as AppView, label: 'Administration', icon: Shield, roles: ['admin'] },
];

export function Sidebar({ isOpen, onClose, currentView, onViewChange, userRole }: SidebarProps) {
  const filteredMenuItems = menuItems.filter(item => item.roles.includes(userRole));

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:relative inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 lg:hidden">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-green-600 to-amber-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">FI</span>
              </div>
              <h2 className="text-lg font-semibold text-gray-900">Ferment'Innov</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="h-5 w-5 text-gray-600" />
            </button>
          </div>

          <nav className="flex-1 p-4 space-y-2">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id);
                    onClose();
                  }}
                  className={`
                    w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200
                    ${isActive 
                      ? 'bg-gradient-to-r from-green-500 to-amber-500 text-white shadow-md' 
                      : 'text-gray-700 hover:bg-gray-100'
                    }
                  `}
                >
                  <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </>
  );
}