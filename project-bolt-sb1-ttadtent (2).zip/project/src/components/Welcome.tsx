import React, { useState } from 'react';
import { Plus, Wifi, QrCode, Users, ArrowRight, CheckCircle2, Smartphone } from 'lucide-react';
import { User } from '../types';
import { MachineSetup } from './machine/MachineSetup';
import { CooperativeManagement } from './cooperative/CooperativeManagement';

interface WelcomeProps {
  user: User;
  onMachineConnected: (machineId: string) => void;
}

const mockMachines = [
  { id: 'FI-2025-001', name: 'Machine Fermentation A', status: 'online', location: 'Bâtiment Principal' },
  { id: 'FI-2025-002', name: 'Machine Séchage B', status: 'offline', location: 'Hangar Sud' },
];

export function Welcome({ user, onMachineConnected }: WelcomeProps) {
  const [showMachineSetup, setShowMachineSetup] = useState(false);
  const [showCooperativeMode, setShowCooperativeMode] = useState(false);

  const handleQuickStart = () => {
    // Simulate connecting to first available machine
    onMachineConnected('FI-2025-001');
  };

  if (showCooperativeMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cacao-50 to-leaf-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="mb-8">
            <button
              onClick={() => setShowCooperativeMode(false)}
              className="text-gray-600 hover:text-gray-800 mb-4 inline-flex items-center space-x-2"
            >
              <ArrowRight className="h-4 w-4 rotate-180" />
              <span>Retour à l'accueil</span>
            </button>
          </div>
          <CooperativeManagement />
        </div>
      </div>
    );
  }

  if (showMachineSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cacao-50 to-leaf-50 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-8">
            <button
              onClick={() => setShowMachineSetup(false)}
              className="text-gray-600 hover:text-gray-800 mb-4 inline-flex items-center space-x-2"
            >
              <ArrowRight className="h-4 w-4 rotate-180" />
              <span>Retour à l'accueil</span>
            </button>
          </div>
          <MachineSetup onComplete={(machineId) => onMachineConnected(machineId)} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cacao-50 to-leaf-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header de bienvenue */}
        <div className="text-center mb-12">
          <div className="w-24 h-24 mx-auto bg-gradient-to-r from-leaf-600 to-burnt-orange-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
            <span className="text-white font-bold text-3xl">FI</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Bienvenue, {user.name.split(' ')[0]} ! 👋
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Prêt à optimiser vos processus de fermentation et séchage des fèves de cacao avec 
            l'intelligence artificielle et l'IoT ?
          </p>
        </div>

        {/* Actions principales */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Connexion première machine */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300">
            <div className="flex items-center space-x-4 mb-6">
              <div className="p-3 bg-gradient-to-r from-leaf-500 to-leaf-600 rounded-xl">
                <Wifi className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">Connecter une Machine</h3>
                <p className="text-gray-600">Associez votre première machine IoT Ferment'Innov</p>
              </div>
            </div>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-leaf-600" />
                <span>Appairage sécurisé via QR code ou ID machine</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-leaf-600" />
                <span>Communication MQTT chiffrée avec AWS IoT Core</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-leaf-600" />
                <span>Contrôle temps réel et notifications push</span>
              </div>
            </div>

            <button
              onClick={() => setShowMachineSetup(true)}
              className="w-full flex items-center justify-center space-x-3 py-4 px-6 bg-gradient-to-r from-leaf-600 to-leaf-700 text-white rounded-xl hover:from-leaf-700 hover:to-leaf-800 transition-all duration-200 font-semibold text-lg shadow-lg"
            >
              <QrCode className="h-6 w-6" />
              <span>Scanner QR Code</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>

          {/* Gestion multi-machines pour coopératives */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 hover:shadow-2xl transition-all duration-300">
            <div className="flex items-center space-x-4 mb-6">
              <div className="p-3 bg-gradient-to-r from-burnt-orange-500 to-burnt-orange-600 rounded-xl">
                <Users className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">Gestion Coopérative</h3>
                <p className="text-gray-600">Gérez plusieurs machines et utilisateurs</p>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-burnt-orange-600" />
                <span>Multi-utilisateurs avec rôles personnalisés</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-burnt-orange-600" />
                <span>Supervision centralisée de toutes les machines</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <CheckCircle2 className="h-5 w-5 text-burnt-orange-600" />
                <span>Rapports consolidés et analytics avancés</span>
              </div>
            </div>

            <button
              onClick={() => setShowCooperativeMode(true)}
              className="w-full flex items-center justify-center space-x-3 py-4 px-6 bg-gradient-to-r from-burnt-orange-500 to-burnt-orange-600 text-white rounded-xl hover:from-burnt-orange-600 hover:to-burnt-orange-700 transition-all duration-200 font-semibold text-lg shadow-lg"
            >
              <Users className="h-6 w-6" />
              <span>Mode Coopérative</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Machines existantes (si applicable) */}
        {user.machineIds && user.machineIds.length > 0 && (
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Vos Machines Connectées</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockMachines.map((machine) => (
                <div key={machine.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      machine.status === 'online' ? 'bg-green-500' : 'bg-gray-400'
                    }`} />
                    <div>
                      <h4 className="font-medium text-gray-900">{machine.name}</h4>
                      <p className="text-sm text-gray-500">{machine.location}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => onMachineConnected(machine.id)}
                    className="px-4 py-2 bg-leaf-100 text-leaf-700 rounded-lg hover:bg-leaf-200 transition-colors font-medium"
                  >
                    Accéder
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Démarrage rapide */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-leaf-50 to-burnt-orange-50 rounded-2xl p-8 border border-leaf-200">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Démarrage Rapide</h3>
            <p className="text-gray-600 mb-6">
              Vous avez déjà une machine configurée ? Accédez directement au dashboard principal.
            </p>
            <button
              onClick={handleQuickStart}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-leaf-600 to-burnt-orange-500 text-white rounded-lg hover:from-leaf-700 hover:to-burnt-orange-600 transition-all duration-200 font-semibold shadow-lg"
            >
              <span>Accéder au Dashboard</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Footer avec informations */}
        <div className="mt-12 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm text-gray-600">
            <div className="flex items-center justify-center space-x-2">
              <div className="w-2 h-2 bg-leaf-500 rounded-full" />
              <span>Connexion sécurisée AWS IoT Core</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <div className="w-2 h-2 bg-burnt-orange-500 rounded-full" />
              <span>Intelligence artificielle intégrée</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <div className="w-2 h-2 bg-leaf-500 rounded-full" />
              <span>Support technique 24/7</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}