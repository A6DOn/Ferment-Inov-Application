import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, AlertTriangle, Lightbulb, Target, Zap } from 'lucide-react';
import { AIService } from '../../services/aws';

interface AIRecommendation {
  id: string;
  type: 'optimization' | 'alert' | 'prediction';
  title: string;
  message: string;
  confidence: number;
  timestamp: string;
  parameters?: Record<string, number>;
}

const aiService = new AIService();

export function AIInsights() {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [aiMode, setAiMode] = useState<'monitoring' | 'optimization' | 'prediction'>('monitoring');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadRecommendations();
  }, []);

  const loadRecommendations = async () => {
    setIsLoading(true);
    try {
      const recs = await aiService.getRecommendations({}, {});
      setRecommendations(recs);
    } catch (error) {
      console.error('Erreur lors du chargement des recommandations IA:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case 'optimization': return <Target className="h-5 w-5" />;
      case 'alert': return <AlertTriangle className="h-5 w-5" />;
      case 'prediction': return <TrendingUp className="h-5 w-5" />;
      default: return <Lightbulb className="h-5 w-5" />;
    }
  };

  const getRecommendationColor = (type: string) => {
    switch (type) {
      case 'optimization': return 'bg-blue-50 border-blue-200 text-blue-800';
      case 'alert': return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'prediction': return 'bg-green-50 border-green-200 text-green-800';
      default: return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
            <Brain className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Intelligence Artificielle</h1>
            <p className="text-sm text-gray-500">Optimisation automatique et recommandations</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
            IA Active
          </div>
          <button
            onClick={loadRecommendations}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200"
          >
            <Zap className="h-4 w-4" />
            <span>Actualiser</span>
          </button>
        </div>
      </div>

      {/* AI Mode Selector */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Mode d'Intelligence Artificielle</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => setAiMode('monitoring')}
            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
              aiMode === 'monitoring'
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                aiMode === 'monitoring' ? 'bg-blue-100' : 'bg-gray-100'
              }`}>
                <AlertTriangle className={`h-5 w-5 ${
                  aiMode === 'monitoring' ? 'text-blue-600' : 'text-gray-600'
                }`} />
              </div>
              <div className="text-left">
                <h4 className="font-medium text-gray-900">Surveillance</h4>
                <p className="text-sm text-gray-500">Alertes et monitoring</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setAiMode('optimization')}
            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
              aiMode === 'optimization'
                ? 'border-green-500 bg-green-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                aiMode === 'optimization' ? 'bg-green-100' : 'bg-gray-100'
              }`}>
                <Target className={`h-5 w-5 ${
                  aiMode === 'optimization' ? 'text-green-600' : 'text-gray-600'
                }`} />
              </div>
              <div className="text-left">
                <h4 className="font-medium text-gray-900">Optimisation</h4>
                <p className="text-sm text-gray-500">Ajustements automatiques</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => setAiMode('prediction')}
            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
              aiMode === 'prediction'
                ? 'border-purple-500 bg-purple-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                aiMode === 'prediction' ? 'bg-purple-100' : 'bg-gray-100'
              }`}>
                <TrendingUp className={`h-5 w-5 ${
                  aiMode === 'prediction' ? 'text-purple-600' : 'text-gray-600'
                }`} />
              </div>
              <div className="text-left">
                <h4 className="font-medium text-gray-900">Prédiction</h4>
                <p className="text-sm text-gray-500">Analyse prédictive</p>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Recommandations IA</h3>
          <p className="text-sm text-gray-500 mt-1">
            Basées sur l'analyse des données capteurs et l'apprentissage machine
          </p>
        </div>

        <div className="p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <span className="ml-3 text-gray-600">Analyse en cours...</span>
            </div>
          ) : (
            <div className="space-y-4">
              {recommendations.map((rec) => (
                <div
                  key={rec.id}
                  className={`p-4 rounded-lg border ${getRecommendationColor(rec.type)}`}
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">
                      {getRecommendationIcon(rec.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{rec.title}</h4>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-medium">
                            Confiance: {Math.round(rec.confidence * 100)}%
                          </span>
                          <div className="w-16 bg-white bg-opacity-50 rounded-full h-2">
                            <div
                              className="bg-current h-2 rounded-full transition-all duration-300"
                              style={{ width: `${rec.confidence * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      <p className="text-sm mb-2">{rec.message}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs opacity-75">
                          {new Date(rec.timestamp).toLocaleString('fr-FR')}
                        </span>
                        {rec.parameters && (
                          <button className="text-xs font-medium hover:underline">
                            Appliquer les paramètres
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* AI Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-green-50 rounded-lg">
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Précision IA</h3>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">94.2%</div>
          <p className="text-sm text-gray-500">Prédictions correctes ce mois</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Zap className="h-5 w-5 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Optimisations</h3>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">127</div>
          <p className="text-sm text-gray-500">Ajustements automatiques</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-purple-50 rounded-lg">
              <Target className="h-5 w-5 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Qualité</h3>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">+18%</div>
          <p className="text-sm text-gray-500">Amélioration qualité moyenne</p>
        </div>
      </div>
    </div>
  );
}