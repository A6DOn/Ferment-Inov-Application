import React, { useState } from 'react';
import { QrCode, Wifi, CheckCircle2, AlertTriangle, Smartphone } from 'lucide-react';

interface MachineSetupProps {
  onComplete?: (machineId: string) => void;
}

export function MachineSetup({ onComplete }: MachineSetupProps) {
  const [setupStep, setSetupStep] = useState<'scan' | 'connect' | 'complete'>('scan');
  const [machineId, setMachineId] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);

  const handleQRScan = () => {
    // Simulate QR code scan
    setIsConnecting(true);
    setTimeout(() => {
      setMachineId('FI-2025-001');
      setSetupStep('connect');
      setIsConnecting(false);
    }, 2000);
  };

  const handleConnect = () => {
    setIsConnecting(true);
    setTimeout(() => {
      setSetupStep('complete');
      setIsConnecting(false);
    }, 3000);
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="text-center mb-6">
        <div className="w-16 h-16 mx-auto bg-gradient-to-r from-green-600 to-amber-600 rounded-2xl flex items-center justify-center mb-4">
          <span className="text-white font-bold text-xl">FI</span>
        </div>
        <h2 className="text-xl font-bold text-gray-900">Configuration Machine IoT</h2>
        <p className="text-sm text-gray-500 mt-1">
          Associez votre compte à une machine Ferment'Innov
        </p>
      </div>

      {setupStep === 'scan' && (
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-32 h-32 mx-auto bg-gray-100 rounded-lg flex items-center justify-center mb-4">
              <QrCode className="h-16 w-16 text-gray-400" />
            </div>
            <h3 className="font-medium text-gray-900 mb-2">Scanner le QR Code</h3>
            <p className="text-sm text-gray-500 mb-4">
              Scannez le QR code présent sur votre machine Ferment'Innov
            </p>
          </div>

          <button
            onClick={handleQRScan}
            disabled={isConnecting}
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200 disabled:opacity-50"
          >
            {isConnecting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Scan en cours...</span>
              </>
            ) : (
              <>
                <Smartphone className="h-4 w-4" />
                <span>Ouvrir le Scanner</span>
              </>
            )}
          </button>

          <div className="text-center">
            <p className="text-xs text-gray-500">
              Ou saisissez manuellement l'identifiant machine
            </p>
            <input
              type="text"
              placeholder="FI-2025-XXX"
              className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-center"
            />
          </div>
        </div>
      )}

      {setupStep === 'connect' && (
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Wifi className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="font-medium text-gray-900 mb-2">Machine Détectée</h3>
            <p className="text-sm text-gray-500 mb-4">
              Machine ID: <span className="font-mono font-medium">{machineId}</span>
            </p>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">Informations Machine</h4>
            <div className="space-y-1 text-sm text-blue-800">
              <div className="flex justify-between">
                <span>Modèle:</span>
                <span>Ferment'Innov Pro</span>
              </div>
              <div className="flex justify-between">
                <span>Version:</span>
                <span>2.1.0</span>
              </div>
              <div className="flex justify-between">
                <span>Statut:</span>
                <span className="text-green-600">En ligne</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleConnect}
            disabled={isConnecting}
            className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200 disabled:opacity-50"
          >
            {isConnecting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Connexion...</span>
              </>
            ) : (
              <>
                <Wifi className="h-4 w-4" />
                <span>Se Connecter</span>
              </>
            )}
          </button>
        </div>
      )}

      {setupStep === 'complete' && (
        <div className="space-y-6 text-center">
          <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Configuration Terminée</h3>
            <p className="text-sm text-gray-500">
              Votre compte est maintenant associé à la machine {machineId}
            </p>
          </div>

          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <div className="space-y-2 text-sm text-green-800">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4" />
                <span>Connexion AWS IoT Core établie</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4" />
                <span>Communication MQTT sécurisée</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4" />
                <span>Notifications push activées</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onComplete?.(machineId)}
            className="w-full py-3 px-4 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200"
          >
            Accéder au Dashboard
          </button>
        </div>
      )}
    </div>
  );
}