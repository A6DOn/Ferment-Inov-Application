import React from 'react';

interface SensorDisplayProps {
  title: string;
  value: string;
  target: string;
  status: 'normal' | 'high' | 'low';
  icon: React.ReactNode;
  color: 'red' | 'blue' | 'green' | 'amber';
}

const colorClasses = {
  red: {
    bg: 'bg-red-50',
    text: 'text-red-600',
    border: 'border-red-200'
  },
  blue: {
    bg: 'bg-blue-50',
    text: 'text-blue-600',
    border: 'border-blue-200'
  },
  green: {
    bg: 'bg-green-50',
    text: 'text-green-600',
    border: 'border-green-200'
  },
  amber: {
    bg: 'bg-amber-50',
    text: 'text-amber-600',
    border: 'border-amber-200'
  }
};

const statusColors = {
  normal: 'text-green-600',
  high: 'text-amber-600',
  low: 'text-blue-600'
};

const statusLabels = {
  normal: 'Normal',
  high: 'Élevé',
  low: 'Bas'
};

export function SensorDisplay({ title, value, target, status, icon, color }: SensorDisplayProps) {
  const colors = colorClasses[color];

  return (
    <div className={`bg-white rounded-xl shadow-sm border ${colors.border} p-6`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colors.bg}`}>
          <div className={colors.text}>
            {icon}
          </div>
        </div>
        <span className={`text-xs font-medium px-2 py-1 rounded-full ${
          status === 'normal' 
            ? 'bg-green-100 text-green-800' 
            : status === 'high'
            ? 'bg-amber-100 text-amber-800'
            : 'bg-blue-100 text-blue-800'
        }`}>
          {statusLabels[status]}
        </span>
      </div>
      
      <h3 className="text-sm font-medium text-gray-600 mb-1">{title}</h3>
      <div className="space-y-1">
        <div className="text-2xl font-bold text-gray-900">{value}</div>
        <div className="text-sm text-gray-500">Cible: {target}</div>
      </div>
    </div>
  );
}