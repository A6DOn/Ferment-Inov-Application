import React, { useState } from 'react';
import { Settings, Zap, Wind, Thermometer, RotateCcw, Battery, AlertTriangle } from 'lucide-react';

interface AdvancedControlsProps {
  mode: 'auto' | 'manual';
  isRunning: boolean;
}

export function AdvancedControls({ mode, isRunning }: AdvancedControlsProps) {
  const [controls, setControls] = useState({
    motorizedVents: 75,
    bidirectionalFans: 60,
    heatingResistance: 45,
    stirring: true,
    batteryLevel: 87,
    autoShutoff: true,
    maxDryingDays: 3.5
  });

  const [alerts, setAlerts] = useState([
    {
      id: '1',
      type: 'warning',
      message: 'Niveau batterie faible (< 20%) prévu dans 8h',
      timestamp: new Date().toISOString()
    }
  ]);

  const handleControlChange = (key: keyof typeof controls, value: number | boolean) => {
    setControls(prev => ({ ...prev, [key]: value }));
  };

  const getBatteryColor = (level: number) => {
    if (level > 60) return 'text-green-600 bg-green-50';
    if (level > 30) return 'text-amber-600 bg-amber-50';
    return 'text-red-600 bg-red-50';
  };

  return (
    <div className="space-y-6">
      {/* System Status */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Settings className="h-5 w-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">Contrôles Avancés IoT</h3>
          </div>
          <div className="flex items-center space-x-4">
            <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${getBatteryColor(controls.batteryLevel)}`}>
              <Battery className="h-4 w-4" />
              <span className="text-sm font-medium">{controls.batteryLevel}%</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              isRunning ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
            }`}>
              {isRunning ? 'ACTIF' : 'ARRÊTÉ'}
            </div>
          </div>
        </div>

        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="mb-6 space-y-2">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-center space-x-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertTriangle className="h-4 w-4 text-amber-600 flex-shrink-0" />
                <span className="text-sm text-amber-800">{alert.message}</span>
              </div>
            ))}
          </div>
        )}

        {/* Advanced Controls Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Motorized Vents */}
          <div className="space-y-4">
            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <div className="flex items-center space-x-2">
                  <Wind className="h-4 w-4" />
                  <span>Orifices Motorisés</span>
                </div>
                <span className="text-gray-500">{controls.motorizedVents}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={controls.motorizedVents}
                onChange={(e) => handleControlChange('motorizedVents', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' ? 'bg-gray-200' : 'bg-blue-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Fermé</span>
                <span>Ouvert</span>
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <div className="flex items-center space-x-2">
                  <RotateCcw className="h-4 w-4" />
                  <span>Ventilateurs Bidirectionnels</span>
                </div>
                <span className="text-gray-500">{controls.bidirectionalFans}%</span>
              </label>
              <input
                type="range"
                min="-100"
                max="100"
                value={controls.bidirectionalFans}
                onChange={(e) => handleControlChange('bidirectionalFans', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' ? 'bg-gray-200' : 'bg-green-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Aspiration</span>
                <span>Soufflage</span>
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <div className="flex items-center space-x-2">
                  <Thermometer className="h-4 w-4" />
                  <span>Résistances Chauffantes</span>
                </div>
                <span className="text-gray-500">{controls.heatingResistance}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={controls.heatingResistance}
                onChange={(e) => handleControlChange('heatingResistance', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' ? 'bg-gray-200' : 'bg-red-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Arrêt</span>
                <span>Maximum</span>
              </div>
            </div>
          </div>

          {/* System Settings */}
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900">Brassage Automatique</h4>
                <p className="text-sm text-gray-500">Rotation périodique des fèves</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={controls.stirring}
                  onChange={(e) => handleControlChange('stirring', e.target.checked)}
                  disabled={mode === 'auto'}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900">Arrêt Automatique</h4>
                <p className="text-sm text-gray-500">Après {controls.maxDryingDays} jours de séchage</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={controls.autoShutoff}
                  onChange={(e) => handleControlChange('autoShutoff', e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">Séquence de Séchage</h4>
              <div className="space-y-2 text-sm text-blue-800">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span>Phase 1: Évacuation humidité (6h)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span>Phase 2: Boucle fermée air chaud</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span>Phase 3: Arrêt automatique</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {mode === 'manual' && (
          <div className="flex justify-end space-x-3 mt-6 pt-6 border-t border-gray-200">
            <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <RotateCcw className="h-4 w-4" />
              <span>Réinitialiser</span>
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200">
              <Zap className="h-4 w-4" />
              <span>Appliquer Paramètres</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}