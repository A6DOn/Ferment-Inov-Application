import React, { useState } from 'react';
import { Thermometer, Droplets, Wind, Zap, Play, Pause, RotateCcw, Brain } from 'lucide-react';
import { ControlPanel } from './ControlPanel';
import { SensorDisplay } from './SensorDisplay';
import { AdvancedControls } from './AdvancedControls';

const mockSensorData = {
  temperature: 45.2,
  humidity: 72,
  ph: 4.2,
  weight: 487.5,
  airflow: 85,
  power: 92,
  batteryLevel: 87
};

export function IoTControl() {
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [isRunning, setIsRunning] = useState(true);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [activeTab, setActiveTab] = useState<'basic' | 'advanced'>('basic');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Contrôle IoT</h1>
        <div className="flex items-center space-x-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setMode('auto')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                mode === 'auto'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Automatique
            </button>
            <button
              onClick={() => setMode('manual')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                mode === 'manual'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Manuel
            </button>
          </div>
          <button
            onClick={() => setAiEnabled(!aiEnabled)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
              aiEnabled
                ? 'bg-purple-100 text-purple-800 hover:bg-purple-200'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Brain className="h-4 w-4" />
            <span>IA {aiEnabled ? 'ON' : 'OFF'}</span>
          </button>
          <div className="flex space-x-2">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                isRunning
                  ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                  : 'bg-green-100 text-green-800 hover:bg-green-200'
              }`}
            >
              {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              <span>{isRunning ? 'Pause' : 'Démarrer'}</span>
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium transition-colors">
              <RotateCcw className="h-4 w-4" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>

      {/* Status Banner */}
      <div className={`rounded-xl p-4 border-l-4 ${
        isRunning
          ? 'bg-green-50 border-green-400'
          : 'bg-amber-50 border-amber-400'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className={`font-medium ${
              isRunning ? 'text-green-800' : 'text-amber-800'
            }`}>
              Système {isRunning ? 'Actif' : 'En Pause'}
            </h3>
            <p className={`text-sm ${
              isRunning ? 'text-green-600' : 'text-amber-600'
            }`}>
              Mode {mode === 'auto' ? 'automatique' : 'manuel'} • IA {aiEnabled ? 'activée' : 'désactivée'} • Lot LOT-2025-001 en fermentation
            </p>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
            isRunning
              ? 'bg-green-100 text-green-800'
              : 'bg-amber-100 text-amber-800'
          }`}>
            {isRunning ? 'ACTIF' : 'PAUSE'}
          </div>
        </div>
      </div>

      {/* Sensor Data Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
        <SensorDisplay
          title="Température"
          value={`${mockSensorData.temperature}°C`}
          target="45°C"
          status="normal"
          icon={<Thermometer className="h-6 w-6" />}
          color="red"
        />
        <SensorDisplay
          title="Humidité"
          value={`${mockSensorData.humidity}%`}
          target="70%"
          status="high"
          icon={<Droplets className="h-6 w-6" />}
          color="blue"
        />
        <SensorDisplay
          title="pH"
          value={`${mockSensorData.ph}`}
          target="4.0"
          status="normal"
          icon={<Zap className="h-6 w-6" />}
          color="green"
        />
        <SensorDisplay
          title="Poids"
          value={`${mockSensorData.weight}kg`}
          target="500kg"
          status="normal"
          icon={<Wind className="h-6 w-6" />}
          color="amber"
        />
        <SensorDisplay
          title="Ventilation"
          value={`${mockSensorData.airflow}%`}
          target="80%"
          status="normal"
          icon={<Wind className="h-6 w-6" />}
          color="green"
        />
        <SensorDisplay
          title="Alimentation"
          value={`${mockSensorData.power}%`}
          target="90%"
          status="normal"
          icon={<Zap className="h-6 w-6" />}
          color="amber"
        />
      </div>

      {/* Control Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('basic')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'basic'
                ? 'border-green-500 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Contrôles de Base
          </button>
          <button
            onClick={() => setActiveTab('advanced')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'advanced'
                ? 'border-green-500 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Contrôles Avancés
          </button>
        </nav>
      </div>

      {/* Control Panels */}
      {activeTab === 'basic' ? (
        <ControlPanel mode={mode} isRunning={isRunning} />
      ) : (
        <AdvancedControls mode={mode} isRunning={isRunning} />
      )}
    </div>
  );
}