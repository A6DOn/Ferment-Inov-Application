import React, { useState } from 'react';
import { Settings, Save, RefreshCw } from 'lucide-react';

interface ControlPanelProps {
  mode: 'auto' | 'manual';
  isRunning: boolean;
}

export function ControlPanel({ mode, isRunning }: ControlPanelProps) {
  const [controls, setControls] = useState({
    temperature: 45,
    humidity: 70,
    ventilation: 80,
    duration: 6
  });

  const handleControlChange = (key: keyof typeof controls, value: number) => {
    setControls(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            <Settings className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Panneau de Contrôle</h2>
            <p className="text-sm text-gray-500">
              {mode === 'auto' 
                ? 'Paramètres automatiques basés sur le type de fève'
                : 'Contrôle manuel des paramètres'
              }
            </p>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <span>Température Cible</span>
                <span className="text-gray-500">{controls.temperature}°C</span>
              </label>
              <input
                type="range"
                min="35"
                max="55"
                value={controls.temperature}
                onChange={(e) => handleControlChange('temperature', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' 
                    ? 'bg-gray-200' 
                    : 'bg-red-200 slider:bg-red-500'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>35°C</span>
                <span>55°C</span>
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <span>Humidité Cible</span>
                <span className="text-gray-500">{controls.humidity}%</span>
              </label>
              <input
                type="range"
                min="40"
                max="80"
                value={controls.humidity}
                onChange={(e) => handleControlChange('humidity', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' 
                    ? 'bg-gray-200' 
                    : 'bg-blue-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>40%</span>
                <span>80%</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <span>Ventilation</span>
                <span className="text-gray-500">{controls.ventilation}%</span>
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={controls.ventilation}
                onChange={(e) => handleControlChange('ventilation', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' 
                    ? 'bg-gray-200' 
                    : 'bg-green-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span>100%</span>
              </div>
            </div>

            <div>
              <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-2">
                <span>Durée (jours)</span>
                <span className="text-gray-500">{controls.duration}j</span>
              </label>
              <input
                type="range"
                min="1"
                max="14"
                value={controls.duration}
                onChange={(e) => handleControlChange('duration', Number(e.target.value))}
                disabled={mode === 'auto'}
                className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                  mode === 'auto' 
                    ? 'bg-gray-200' 
                    : 'bg-amber-200'
                }`}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>1j</span>
                <span>14j</span>
              </div>
            </div>
          </div>
        </div>

        {mode === 'manual' && (
          <div className="flex justify-end space-x-3 mt-6 pt-6 border-t border-gray-200">
            <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <RefreshCw className="h-4 w-4" />
              <span>Réinitialiser</span>
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-amber-600 text-white rounded-lg hover:from-green-700 hover:to-amber-700 transition-all duration-200">
              <Save className="h-4 w-4" />
              <span>Appliquer</span>
            </button>
          </div>
        )}

        {mode === 'auto' && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Mode automatique activé:</strong> Les paramètres sont ajustés automatiquement selon le type de fève sélectionné et les conditions environnementales.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}