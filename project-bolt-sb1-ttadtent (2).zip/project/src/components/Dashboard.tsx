import React from 'react';
import { Thermometer, Droplets, Clock, TrendingUp, AlertTriangle, CheckCircle2, Sun, CloudRain } from 'lucide-react';
import { StatCard } from './ui/StatCard';
import { ProgressCard } from './ui/ProgressCard';
import { AlertCard } from './ui/AlertCard';

const mockLots = [
  {
    id: 'LOT-2025-001',
    type: 'Trinitario',
    phase: 'Fermentation',
    day: 3,
    totalDays: 6,
    temperature: 45.2,
    humidity: 72,
    status: 'normal'
  },
  {
    id: 'LOT-2025-002',
    type: 'Forastero',
    phase: 'Séchage',
    day: 2,
    totalDays: 8,
    temperature: 38.5,
    humidity: 45,
    status: 'warning'
  }
];

const weatherData = {
  temperature: 29,
  humidity: 78,
  condition: 'Partiellement nuageux',
  icon: Sun
};

export function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <div className="text-sm text-gray-500">
          Dernière mise à jour: {new Date().toLocaleTimeString('fr-FR')}
        </div>
      </div>

      {/* Weather Widget */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">Conditions Météo Actuelles</h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Thermometer className="h-5 w-5" />
                <span className="text-2xl font-bold">{weatherData.temperature}°C</span>
              </div>
              <div className="flex items-center space-x-2">
                <Droplets className="h-5 w-5" />
                <span>{weatherData.humidity}%</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <weatherData.icon className="h-12 w-12 mb-2 ml-auto" />
            <p className="text-sm opacity-90">{weatherData.condition}</p>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Lots Actifs"
          value="2"
          icon={<TrendingUp className="h-6 w-6" />}
          trend="+1 cette semaine"
          color="green"
        />
        <StatCard
          title="En Fermentation"
          value="1"
          icon={<Thermometer className="h-6 w-6" />}
          trend="Jour 3/6"
          color="blue"
        />
        <StatCard
          title="En Séchage"
          value="1"
          icon={<Sun className="h-6 w-6" />}
          trend="Jour 2/8"
          color="amber"
        />
        <StatCard
          title="Alertes Actives"
          value="1"
          icon={<AlertTriangle className="h-6 w-6" />}
          trend="Humidité élevée"
          color="red"
        />
      </div>

      {/* Active Lots */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockLots.map((lot) => (
          <div key={lot.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{lot.id}</h3>
                <p className="text-sm text-gray-500">{lot.type} • {lot.phase}</p>
              </div>
              <div className={`
                px-3 py-1 rounded-full text-xs font-medium
                ${lot.status === 'normal' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}
              `}>
                {lot.status === 'normal' ? 'Normal' : 'Attention'}
              </div>
            </div>

            <ProgressCard
              label="Progression"
              current={lot.day}
              total={lot.totalDays}
              color={lot.phase === 'Fermentation' ? 'blue' : 'amber'}
            />

            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-50 rounded-lg">
                  <Thermometer className="h-4 w-4 text-red-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Température</p>
                  <p className="font-semibold text-gray-900">{lot.temperature}°C</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Droplets className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Humidité</p>
                  <p className="font-semibold text-gray-900">{lot.humidity}%</p>
                </div>
              </div>
            </div>

            {lot.status === 'warning' && (
              <AlertCard
                type="warning"
                title="Humidité élevée détectée"
                message="Le taux d'humidité dépasse les recommandations pour cette phase."
                className="mt-4"
              />
            )}
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions Rapides</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left">
            <div className="p-2 bg-green-50 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Nouveau Lot</p>
              <p className="text-xs text-gray-500">Créer un lot</p>
            </div>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Thermometer className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Contrôle IoT</p>
              <p className="text-xs text-gray-500">Ajuster paramètres</p>
            </div>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left">
            <div className="p-2 bg-amber-50 rounded-lg">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Historique</p>
              <p className="text-xs text-gray-500">Voir les données</p>
            </div>
          </button>
          <button className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-left">
            <div className="p-2 bg-purple-50 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Rapport</p>
              <p className="text-xs text-gray-500">Générer PDF</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}