import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Welcome } from './components/Welcome';
import { Dashboard } from './components/Dashboard';
import { LoginForm } from './components/auth/LoginForm';
import { ContactSupport } from './components/support/ContactSupport';
import { LotManagement } from './components/lots/LotManagement';
import { IoTControl } from './components/iot/IoTControl';
import { AIInsights } from './components/ai/AIInsights';
import { Documentation } from './components/Documentation';
import { Administration } from './components/Administration';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'operator' | 'viewer';
}

export type AppView = 'dashboard' | 'lots' | 'iot-control' | 'ai-insights' | 'documentation' | 'admin';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [hasConnectedMachine, setHasConnectedMachine] = useState(false);
  const [showSupport, setShowSupport] = useState(false);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-green-50">
        <LoginForm onLogin={setUser} />
      </div>
    );
  }

  // Show welcome page if user hasn't connected a machine yet
  if (!hasConnectedMachine && (!user.machineIds || user.machineIds.length === 0)) {
    return (
      <Welcome 
        user={user} 
        onMachineConnected={(machineId) => {
          setHasConnectedMachine(true);
          // Update user with connected machine
          setUser(prev => prev ? {
            ...prev,
            machineIds: [...(prev.machineIds || []), machineId]
          } : null);
        }} 
      />
    );
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'lots':
        return <LotManagement />;
      case 'iot-control':
        return <IoTControl />;
      case 'ai-insights':
        return <AIInsights />;
      case 'documentation':
        return <Documentation />;
      case 'admin':
        return user.role === 'admin' ? <Administration /> : <Dashboard />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        currentView={currentView}
        onViewChange={setCurrentView}
        userRole={user.role}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          user={user}
          onMenuClick={() => setSidebarOpen(true)}
          onLogout={() => setUser(null)}
          onSupportClick={() => setShowSupport(true)}
        />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 lg:p-6">
          {renderCurrentView()}
        </main>
      </div>
      <ContactSupport 
        isOpen={showSupport} 
        onClose={() => setShowSupport(false)} 
      />
    </div>
  );
}

export default App;