export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'admin' | 'operator' | 'viewer';
  cooperativeId?: string;
  machineIds?: string[];
}

export interface Machine {
  id: string;
  name: string;
  qrCode: string;
  status: 'online' | 'offline' | 'maintenance';
  location: string;
  cooperativeId?: string;
}

export interface Lot {
  id: string;
  type: 'Trinitario' | 'Forastero' | 'Criollo' | 'Nacional';
  quantity: number;
  phase: 'Fermentation' | 'Séchage' | 'Terminé';
  status: 'active' | 'completed' | 'paused';
  startDate: string;
  currentDay: number;
  totalDays: number;
  machineId: string;
  quality: 'excellent' | 'good' | 'average';
  aiRecommendations?: string[];
}

export interface SensorData {
  temperature: number;
  humidity: number;
  ph?: number;
  weight?: number;
  airflow: number;
  power: number;
  batteryLevel: number;
  timestamp: string;
}

export interface IoTControl {
  mode: 'auto' | 'manual';
  isRunning: boolean;
  motorizedVents: number; // 0-100%
  bidirectionalFans: number; // -100 to 100% (negative = reverse)
  heatingResistance: number; // 0-100%
  stirring: boolean;
  aiEnabled: boolean;
}

export interface AIRecommendation {
  id: string;
  type: 'optimization' | 'alert' | 'prediction';
  title: string;
  message: string;
  confidence: number;
  timestamp: string;
  parameters?: Record<string, number>;
}

export type AppView = 'dashboard' | 'lots' | 'iot-control' | 'ai-insights' | 'documentation' | 'admin';