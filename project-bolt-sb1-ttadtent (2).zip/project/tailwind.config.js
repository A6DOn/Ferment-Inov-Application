/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'cacao': {
          50: '#FAF6E8',  // Beurre de cacao clair
          100: '#F5EDD3',
          200: '#E8D5A7',
          300: '#DBBD7B',
          400: '#CEA54F',
          500: '#B8941F',
          600: '#8B6914',
          700: '#5E3E0A',
          800: '#3F2907',
          900: '#1F1403',
        },
        'leaf': {
          50: '#F0F9F0',
          100: '#E1F3E1',
          200: '#C3E7C3',
          300: '#A5DBA5',
          400: '#87CF87',
          500: '#69C369',
          600: '#4A9C4A',
          700: '#2B752B',
          800: '#1C4E1C',
          900: '#0E270E',
        },
        'burnt-orange': {
          50: '#FFF4E6',
          100: '#FFE9CC',
          200: '#FFD399',
          300: '#FFBD66',
          400: '#FFA733',
          500: '#FF9100',
          600: '#CC7400',
          700: '#995700',
          800: '#663A00',
          900: '#331D00',
        }
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'pulse-slow': 'pulse 3s infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      }
    },
  },
  plugins: [],
};
